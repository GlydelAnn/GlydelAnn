<div align="center">
    <a href="https://github.com/JurielUC">
        <img src="assets/logo.png" alt="Logo" width="200">
    </a>
</div>

# Hello, I'm Juriel!

### Socials: 
<a href="https://www.instagram.com/jurielcomia/"><img src="https://img.shields.io/badge/instagram-%23E4405F.svg?&style=for-the-badge&logo=instagram&logoColor=white"></a>  <a href="https://www.linkedin.com/in/juriel-comia-49769525a/"><img src="https://img.shields.io/badge/linkedin-%230077B5.svg?&style=for-the-badge&logo=linkedin&logoColor=white"></a> <a href="https://www.facebook.com/juriel.comia.7"><img src="https://img.shields.io/badge/facebook-1877F2?style=for-the-badge&logo=facebook&logoColor=white"></a>
<br>
### How to reach me: 
<a href="mailto: juriel.ucomia@gmail.com">
<img src="https://img.shields.io/badge/gmail-7B83EB?&style=for-the-badge&logo=gmail&color=D14836&logoColor=white" ></a>

### Current Status Quo:

- 💼 Web Developer
- 🔍 I’m looking for connections in <strong>Web Development</strong> Industry.
- 💬 Feel free to discuss with me about <strong>Web Development</strong>.

------------------------------------------- 

### Tools I work upon:

<img src="https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white">   <img src="https://img.shields.io/badge/css3%20-%2314354C.svg?&style=for-the-badge&logo=css3&logoColor=white">   <img src="https://img.shields.io/badge/javascript%20-%23323330.svg?&style=for-the-badge&logo=javascript&logoColor=%23F7DF1E">   <img src="https://img.shields.io/badge/react%20js-%2320232a.svg?style=for-the-badge&logo=react&logoColor=%2361DAFB">   <img src="https://img.shields.io/badge/laravel%20-%23E34F26.svg?&style=for-the-badge&logo=laravel&logoColor=white">   <img src="https://img.shields.io/badge/mysql%20-%23323330.svg?&style=for-the-badge&logo=mysql">   <img src="https://img.shields.io/badge/git%20-%23F05032.svg?&style=for-the-badge&logo=git&logoColor=white"/>   <img src="http://img.shields.io/badge/-VS%20Code-000000?style=for-the-badge&logo=Visual-studio-code&logoColor=blue">   <img src="https://img.shields.io/badge/Canva-%2300C4CC.svg?style=for-the-badge&logo=Canva&logoColor=white">   <img src="https://img.shields.io/badge/figma-%23F24E1E.svg?style=for-the-badge&logo=figma&logoColor=white"> 

------------------------------------------- 

<div align="center">
    <img src="https://github-readme-stats.vercel.app/api/top-langs?username=JurielUC&locale=en&hide_title=false&layout=compact&card_width=320&langs_count=5&theme=dark&hide_border=false" height="150" alt="languages graph"  />
    <img src="https://streak-stats.demolab.com?user=JurielUC&locale=en&mode=daily&theme=dark&hide_border=false&border_radius=5&order=3" height="150" alt="streak graph"  />
<div>
